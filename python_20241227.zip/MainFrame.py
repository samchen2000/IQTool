import tkinter as tk
from tkinter import *
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfile
from PIL import Image, ImageTk
import time
import cv2
from queue import Queue
from threading import Thread
import sys
import getopt
import numpy as np

class Main_GUI():
    def __init__(self, w = 1080, h = 640):
        #self = tk.Tk()
        left = 50
        top = 50
        self.width = w
        self.height = h
        self.mygui = Tk(className="影像處理主介面")
        #self.mygui.geometry(str(self.width)+'x'+str(self.height))
        self.mygui.geometry(f'{self.width}x{self.height}+{left}+{top}')  # 定義視窗的尺寸和位置
        self.mygui.resizable(False, False)  # 固定視窗大小
        self.mygui.grid()
        self.createWiget()
        self.LableFrame()
        self.Button()
        self.Table()
        self.cam_frame()
        self.radiobutton()
        '''
        self.mygui = Tk(className="影像處理技術")
        self.mygui.geometry(f'{width}x{height}+{left}+{top}')  # 定義視窗的尺寸和位置
        self.mygui.title('主畫面')
        self.mygui.resizable(False, False)  # 固定視窗大小
        self.mygui.grid()
        self.Button()
        #self.cam_frame()
        '''        
    def Button(self):
        #增加按鍵
        contrast_But = tk.Button(self.mygui,padx=1,pady=1,text="對比度", font=('宋体', 12, 'bold'), bg='pink')
        contrast_But.place(relx=0.85, rely=0.05, relwidth=0.1, relheight=0.06)
        brightness_But = tk.Button(self.mygui,padx=1, pady=1, text="明亮度", font=('宋体', 12, 'bold'), bg= 'yellow')
        brightness_But.place(relx=0.85, rely=0.15, relwidth=0.1, relheight=0.06)
        sharpness_But = tk.Button(self.mygui,padx=1, pady=1, text="銳利度", font=('宋体', 12 , 'bold'), bg='green')
        sharpness_But.place(relx=0.85, rely=0.25, relwidth=0.1, relheight=0.06)
        hue_But = tk.Button(self.mygui, padx=1, pady=1, text="色相", font=('宋体', 12, 'bold'), bg='blue')
        hue_But.place(relx=0.85, rely=0.35, relwidth=0.1, relheight=0.06)
        color_But = tk.Button(self.mygui, padx=1, pady=1, text="色度", font=('宋体', 12, 'bold'), bg='red')
        color_But.place(relx=0.85, rely=0.45, relwidth=0.1, relheight=0.06)
            
    def Table(self):
        contrast_Lab = tk.Label(self.mygui, text='對比')
        contrast_Lab.place(relx=0.8, rely=0.05, relwidth=0.06, relheight=0.06)
        brightness_Lab = tk.Label(self.mygui, text='明亮')
        brightness_Lab.place(relx=0.8, rely=0.15, relwidth=0.06, relheight=0.06)
        sharpness_Lab = tk.Label(self.mygui, text='銳利')
        sharpness_Lab.place(relx=0.8, rely=0.25, relwidth=0.06, relheight=0.06)
        hue_Lab = tk.Label(self.mygui, text='色相')
        hue_Lab.place(relx=0.8, rely=0.35, relwidth=0.06, relheight=0.06)
        color_Lab = tk.Label(self.mygui, text='顏色')
        color_Lab.place(relx=0.8, rely=0.45, relwidth=0.06, relheight=0.06)
    
    def LableFrame(self):
        camera_Lab_frame = tk.LabelFrame(self.mygui, font=(12), text='main cam')
        camera_Lab_frame.place(relx=0.005, rely=0.01, relwidth=0.65, relheight=0.55)
        cam_contrel_Lab_frame = tk.LabelFrame(self.mygui, font=(12), text='相機控制')
        cam_contrel_Lab_frame.place(relx=0.66, rely=0.01, relwidth=0.3, relheight=0.55)
        face_detect_Lab_frame = tk.LabelFrame(self.mygui, font=(12), text='人臉偵測控制')
        face_detect_Lab_frame.place(relx=0.005, rely=0.56, relwidth=0.3, relheight=0.4)
        article_detect_Lab_frame = tk.LabelFrame(self.mygui, font=(12), text='物品偵測控制')
        article_detect_Lab_frame.place(relx=0.31, rely=0.56, relwidth=0.33, relheight=0.4)
        number_Lab_frame = tk.LabelFrame(self.mygui, font=(12), text='車牌偵測控制')
        number_Lab_frame.place(relx=0.65, rely=0.56, relwidth=0.34, relheight=0.4)
    
    def cam_frame(self):
        cam_frome1 = tk.Frame(self.mygui, width=640, height=480, relief='raised', bg='gray', bd='5')
        #cam_frome1.pack()
        cam_frome1.place(relx=0.01, rely=0.05, relwidth=0.64, relheight=0.48)
        label1 = tk.Label(cam_frome1, text='camera NO.1', width=10, bg='blue')
        label1.pack()
        
    def radiobutton(self):
        val = tk.StringVar()
        video_btn_FixAE = tk.Radiobutton(self.mygui, text='exposure', font=('宋体', 12, 'bold'), variable=val, value=1)
        video_btn_FixAE.place(relx=0.02, rely=0.60, relwidth=0.15, relheight=0.05)
        #video_btn_FixAE.pack(fill='x', side='bottom')
        #video_btn_FixAE.select()  # 搭配 select() 方法選取 radio_btn_FixAE

        video_btn_FixColor = tk.Radiobutton(self.mygui, text='WitchBalances', font=('宋体', 12, 'bold'), variable=val, value=2)
        video_btn_FixColor.place(relx=0.02, rely=0.65, relwidth=0.15, relheight=0.05)
        #video_btn_FixColor.pack(fill='y', side='bottom')
       # self.v2.set(1)
        print(f'val={val}')
    
    def entry(self):
        contrast_entry = tk.Entry(self.mygui, font=(12))
        
        
    def createWiget(self):
        # ---------------菜單欄--------------------
        self.mymenu = Menu(self.mygui)

        # 建立下拉選單
        
        # 文件菜單
        filemenu = Menu(self.mymenu, tearoff=0)
        filemenu.add_command(label='打開圖片', command=self.command_open)
        filemenu.add_command(label='開啟UVC cam', command=self.show_cam)
        filemenu.add_separator()
        filemenu.add_command(label='關閉', command=self.command_exit)
        
        self.mymenu.add_cascade(label="文件", menu=filemenu)
        
        # 二值化菜單
        self.mymenu.add_command(label="二值化", command=self.command_threshold)
        self.mygui.config(menu=self.mymenu)
        # RGB 菜單
        self.mymenu.add_command(label="RGB", command=self.cam_frame)
        self.mygui.config(menu=self.mymenu)
        # 幫助菜單
        self.mymenu.add_command(label="幫助", command=self.command_help)
        self.mygui.config(menu=self.mymenu)

        # ---------------圖片控件------------------- 變量3->label
        self.label = Label(self.mygui, width=self.width, height=self.height)
        self.label.place(relx=0.01, rely=0.01)    

    def command_open(self):
        global img
        filename = askopenfilename(initialdir='Sample.bmp')
        self.image = Image.open(filename)
        image1 = self.image.resize((self.width, self.height), Image.LANCZOS)
        img = ImageTk.PhotoImage(image1)  #轉換格式
        self.label['image'] = img

    def Threshold(self):
        global img1
        img1 = np.array(self.image)
        self.low = self.v1.get()
        self.choice = self.v2.get()
        w, h = self.image.size
        if (self.choice == 1):
            for j in range(h):
                for i in range(w):
                    if img1[j, i] < self.low:
                       img1[j, i] = 255
                    else:
                       img1[j, i] = 0
        elif (self.choice == 2):
            for j in range(h):
                for i in range(w):
                    if img1[j, i] < self.low:
                       img1[j, i] = 0
                    else:
                       img1[j, i] = 255
        image1 = Image.fromarray(np.uint8(img1))
        image1 = image1.resize((self.width, self.height), Image.LANCZOS)
        img1 = ImageTk.PhotoImage(image1)  # 轉格式
        self.label['image'] = img1

    def pic_cancel(self):
        self.top.destroy()

    def show_cam(self):
        source = "rtsp://192.168.1.10/video0"
        vid_cam = cv2.VideoCapture(0)
        if not vid_cam.isOpened():
            print('無法打開攝影機')
            exit()
        while(vid_cam.isOpened()):
           # vid_cam.get = cv2.COLOR_BGR2GRAY
           # ret, image_frame = vid_cam.read()
            ret, self.cam_frame = vid_cam.read() 
            #TODO : 使用可以測試的環境進行測試
            
            cv2.imshow('UVC CAM', self.cam_frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        vid_cam.release()
        cv2.destroyAllWindows()

    def command_threshold(self):
        self.top = Toplevel(width=500, height=250)
        # 增加標題
        self.top.title('二值化處理')
        # 增加按鈕
        bottom1 = tk.Button(self.top, text='二值處理', font=('宋体', 16), command=self.Threshold)
        bottom1.place(relx=0.2, rely=0.8, relwidth=0.16, relheight=0.12)
        bottom2 = tk.Button(self.top, text='關閉', font=('宋体', 16), command=self.pic_cancel)
        bottom2.place(relx=0.6, rely=0.8, relwidth=0.16, relheight=0.12)
        # 增加標籤
        Label1 = tk.Label(self.top, text="閥值", font=('宋体', 16))
        Label1.place(relx=0.01, rely=0.3, relwidth=0.16, relheight=0.12)
        # 增加本文框
        self.v1 = IntVar()
        self.Entry1 = tk.Entry(self.top, textvariable=self.v1, font=('Times New Roman', 16))
        self.Entry1.place(relx=0.16, rely=0.3, relwidth=0.15, relheight=0.12)
        self.v1.set(100)
        # 增加單選按鈕
        LabelFrame1 = tk.LabelFrame(self.top, text="白像素", font=('宋体', 16))
        LabelFrame1.place(relx=0.35, rely=0.1, relwidth=0.5, relheight=0.5)
        self.v2 = IntVar()

        Radiobutton1 = tk.Radiobutton(LabelFrame1, text='以下', font=('宋体', 16), variable=self.v2, value=1)
        Radiobutton1.place(relx=0.1, rely=0.4, relwidth=0.25, relheight=0.2)
        Radiobutton2 = tk.Radiobutton(LabelFrame1, text='以上', font=('宋体', 16), variable=self.v2, value=2)
        Radiobutton2.place(relx=0.4, rely=0.4, relwidth=0.25, relheight=0.2)
        self.v2.set(1)
    def command_rgbData(self):
        exit()
    
    def command_exit(self):
        exit()
    
    def command_help(self):
        user_name = input("關於學習過程需要不斷的練習,要有明確的目標,勇往向前.")

if __name__ == "__main__":
    root = Main_GUI()
    mainloop()