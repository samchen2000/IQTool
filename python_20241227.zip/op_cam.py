
import cv2
import ffmpeg
import numpy as np

source = "rtsp://192.168.1.10/video0"
vid_cam = cv2.VideoCapture(index=0)
#vid_cam = cv2.VideoCapture(source)
img = np.zeros((1920,1080,3),dtype = 'uint8')
#先设置参数，然后读取参数
vid_cam.set(3,1280)
vid_cam.set(propId=4,value=720)
#vid_cam.set(15, 0.1)
arr = np.array([1, 2, 3, 4, 5])
print(arr)    # [1 2 3 4 5]
print("width={}".format(vid_cam.get(3)))
print("height={}".format(vid_cam.get(4)))
print("FPS={}".format(vid_cam.get(5)))
print("Brightness={}".format(vid_cam.get(10)))
print("Contrast={}".format(vid_cam.get(11)))
print("Saturation={}".format(vid_cam.get(12)))
print("HUE={}".format(vid_cam.get(13)))
print("GAIN={}".format(vid_cam.get(14)))
print("exposure={}".format(vid_cam.get(15)))
print("White Balance={}".format(vid_cam.get(17)))
#print("test = {}",format (test)  )
#while True:
if not vid_cam.isOpened():
    print('無法打開攝影機')
    exit()

while(vid_cam.isOpened()):
    ret, image_frame = vid_cam.read() 
    #TODO : 使用可以測試的環境進行測試
    cv2.line,(image_frame,(50,50),(250,250),(0,0,255),10)
    cv2.imshow('UVC Cam', image_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
vid_cam.release()
cv2.destroyAllWindows()