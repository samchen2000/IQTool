import math

angle = 90 #設定角度
angle_1 = 60
radians = math.radians(angle)   #將角度轉換為弧度  radians = angle * Pi / 180
sin_value = math.sin(radians)   #計算正弦值
angle_value = math.cos(angle_1)
print(f'radians={radians}')
print(f'sin value={sin_value}')
print(f'angle_value={angle_value}')